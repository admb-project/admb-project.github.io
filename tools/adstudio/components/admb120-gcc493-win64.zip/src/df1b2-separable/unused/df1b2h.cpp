/*
 * $Id$
 *
 * Author: David Fournier
 * Copyright (c) 2008-2012 Regents of the University of California
 */
/**
 * \file
 * Description not yet available.
 */
#if defined(__GNUC__) && (__GNUC__ < 3)
  #pragma implementation "df1b2fun.h"
#endif

#define HOME_VERSION
#include "df1b2fun.h"
#undef HOME_VERSION
