For more information on glmmadmb, check project page at

http://glmmadmb.r-forge.r-project.org/
