int ad2csv(int argc, char** argv);

int main(int argc, char** argv)
{
  return ad2csv(argc, argv);
}
