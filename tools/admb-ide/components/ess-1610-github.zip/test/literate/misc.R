
##### Indentation

### 1 ----------------------------------------------------------------

  {
          fun¶_call(
argument
) +
stuff1
 } +
stuff2

##! "C-M-q"

  {
          fun¶_call(
              argument
          ) +
              stuff1
 } +
stuff2

##! "C-u"
##! "C-M-q"

{
    fun¶_call(
        argument
    ) +
        stuff1
} +
    stuff2

