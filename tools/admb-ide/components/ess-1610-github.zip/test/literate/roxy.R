
##### Filling

### 1a ---------------------------------------------------------------

##' Title
##'
##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL

##! (fill-paragraph)

##' Title
##'
##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL


### 1b ---------------------------------------------------------------

##' Title
##'
¶##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL

##! (fill-paragraph)

##' Title
##'
¶##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
##' @param Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor incididunt ut labore et dolore magna
##'     aliqua. Ut enim ad minim veniam, quis nostrud exercitation
##'     ullamco laboris nisi ut aliquip ex ea commodo consequat.
NULL


### 2 ----------------------------------------------------------------

##' ¶

##! "RET"

##'
##' ¶

##> "RET"

##'
##'
##' ¶

##> (setq ess-roxy-insert-prefix-on-newline nil)
##> "RET"

##'
##'
##'
¶

##! "M-j"

##'
##' ¶


### 3 ----------------------------------------------------------------

##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor `incididunt' ut labore et ``dolore'' magna aliqua.
NULL

##! (fill-paragraph)

##' @param¶ Lorem ipsum dolor sit amet, consectetur adipiscing elit,
##'     sed do eiusmod tempor `incididunt' ut labore et ``dolore''
##'     magna aliqua.
NULL

