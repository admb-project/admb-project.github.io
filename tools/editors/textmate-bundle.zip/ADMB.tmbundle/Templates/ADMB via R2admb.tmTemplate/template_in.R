library(R2admb)
setup_admb()

write_dat("${TM_NEW_FILE_BASENAME}", L=list( ))

write_pin("${TM_NEW_FILE_BASENAME}", L=list( ))

compile_admb("${TM_NEW_FILE_BASENAME}", verbose=TRUE)

run_admb("${TM_NEW_FILE_BASENAME}", verbose=TRUE)

m_admb=read_admb("${TM_NEW_FILE_BASENAME}")

clean_admb("${TM_NEW_FILE_BASENAME}")