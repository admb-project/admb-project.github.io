library(R2admb)
setup_admb()
library(MCMCpack)
library(coda)

write_dat("${TM_NEW_FILE_BASENAME}", L=list( ))

write_pin("${TM_NEW_FILE_BASENAME}", L=list( ))

compile_admb("${TM_NEW_FILE_BASENAME}", verbose=TRUE)

run_admb("${TM_NEW_FILE_BASENAME}", verbose=TRUE, 
	mcmc=TRUE, 
	mcmc.opts=mcmc.control(mcmc=1000, mcmcpars=c("x"))))

m_admb=read_admb("${TM_NEW_FILE_BASENAME}",  mcmc=TRUE, checkterm=FALSE)

clean_admb("${TM_NEW_FILE_BASENAME}")

mmc=as.mcmc(m_admb$mcmc)
densityplot(mmc, asp="fill")