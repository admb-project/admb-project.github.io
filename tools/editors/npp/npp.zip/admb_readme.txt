ADMB support in Notepad++
by Teresa A'mar (NOAA, Seattle)

1 Make sure you have Notepad++ version 5.5.1 or newer

2 Copy langs.xml and langs.model.xml to the Notepad++ main directory,
  overwriting the old file(s)

3 Copy Zenburn.xml to the Notepad++ themes directory, overwriting the old file

4 Open ADMB source file (*.tpl) in Notepad++

5 Settings - Style Configurator - Select Theme: Zenburn - Save and Close

6 Languages - C - C++

7 Close Notepad++

8 Open ADMB source file (*.tpl) again in Notepad++

Notepad++ should now show ADMB source code in syntax-specific colors on a dark
background.
