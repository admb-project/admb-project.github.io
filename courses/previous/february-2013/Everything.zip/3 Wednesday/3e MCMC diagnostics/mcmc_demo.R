################################################################################
###                                                                            #
### Script:    mcmc_demo.R                                                     #
###                                                                            #
### Purpose:   Plot and discuss MCMC diagnostics from a Schaefer model         #
###                                                                            #
### Requires:  package:scapeMCMC, mcmc_bio.csv, mcmc_par.csv                   #
###                                                                            #
### Notes:     mcmc_bio.csv and mcmc_par.csv are output files from pella.tpl   #
### Notes:     To create those files, run:                                     #
###              pella -ind hake_schaefer.dat -mcmc 1e6 -mcsave 1e3            #
###              pella -ind hake_schaefer.dat -mceval                          #
###                                                                            #
### History:   2013-20-02 Arni Magnusson created for ICES ADMB workshop        #
###                                                                            #
################################################################################

## 1  Import parameter traces
par <- read.csv("c:/pella/mcmc_par.csv")
head(par)
par <- par[-c(1,4,5)]

## 2  Diagnostic plots
require(scapeMCMC)
plotTrace(par)
plotCumu(par)
plotAuto(par)
plotSplom(par)
plotSplom(log(par))

## 3  Posterior plots
plotDens(par)

## 4  Derived quantities (biomass)
bio <- read.csv("c:/pella/mcmc_bio.csv")
head(bio)
names(bio) <- 1965:1988
plotTrace(bio)
plotDens(bio)
plotQuant(bio)
plotQuant(bio, "lines")
