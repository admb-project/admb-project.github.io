#include <cmath>
#include <iostream>
using namespace std;

class result {
  private: double v,d;
  public: result(){v = 0;d= 0;};
          result(double val){v = val; d = 0;};
          result(double val,double der){v = val; d = der;};
          double Value(){return v;};   
          double Deriv(){return d;};                                        
};

class parameter: public result {
  public: parameter(double pval) : result(pval,1.0) {};
          parameter() : result(0.0,1.0) {};                                 
};

result sin(result n){
  return result(sin(n.Value()), cos(n.Value())*n.Deriv());
};

result operator*(result n1,result n2){
  return(result(n1.Value()*n2.Value(), n1.Deriv()*n2.Value() + n2.Deriv()*n1.Value()));
};

ostream& operator<<(ostream& o,result n){
  o << n.Value() << " (Derivative: " << n.Deriv() << ") ";
  return o;
}

int main(int argc, char* argv[]){
  parameter theta(2);
  result y;
  y = sin(theta*theta);
  cout << "The result is " << y << endl;
}
