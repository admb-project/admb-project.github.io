library(glmmADMB)

?glmmADMB

data(bacteria, package="MASS")
bacteria$present <- as.integer(bacteria$y) - 1L
fm <- glmmadmb(present ~ trt + I(week>2), random=~1|ID, family="binomial", data=bacteria)

fm
summary(fm)

logLik(fm)
coef(fm)
ranef(fm)
fitted(fm)
residuals(fm)
fm$S
