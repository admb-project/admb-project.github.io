## Data
library(nlme)
ortho <- with(Orthodont[Orthodont$Sex=="Female",],
              data.frame(Subject=factor(as.character(Subject)),
                         age=age, distance=distance))


## LM (simple)
ortho.simple <- lm(distance~age, data=ortho)
coef(ortho.simple)
summary(ortho.simple)$sigma
fit.simple <- data.frame(Subject=ortho$Subject, age=ortho$age,
                         distance=c(ortho$distance,fitted(ortho.simple)),
                         Series=rep(c("Obs","Pred"),each=nrow(ortho)))
plot(distance~age, data=fit.simple); abline(ortho.simple)
xyplot(distance~age|Subject, groups=Series, data=fit.simple, layout=c(11,1),
       panel=panel.superpose.2, type=c("p","l"), col="black", lwd=2,
       main="\nLM (simple)")


## LM (ancova)
ortho.lm <- lm(distance~Subject+age, data=ortho)
coef(ortho.lm)
summary(ortho.lm)$sigma
fit.lm <- data.frame(Subject=ortho$Subject, age=ortho$age,
                     distance=c(ortho$distance,fitted(ortho.lm)),
                     Series=rep(c("Obs","Pred"),each=nrow(ortho)))
xyplot(distance~age|Subject, groups=Series, data=fit.lm, layout=c(11,1),
       panel=panel.superpose.2, type=c("p","l"), col="black", lwd=2,
       main="\nLM (ancova)")


## LME
ortho.lme <- lme(distance~age, random=~1|Subject, data=ortho)
ortho.lme
ranef(ortho.lme)

ortho.lmeML <- update(ortho.lme, method="ML")
ortho.lmeML
ranef(ortho.lmeML)

fit.all <- data.frame(Subject=ortho$Subject, age=ortho$age,
                      distance=c(ortho$distance,fitted(ortho.lm),
                        fitted(ortho.lme),fitted(ortho.lmeML)),
                      Series=rep(c("data","lm","lme","lmeML"),each=nrow(ortho)))

xyplot(distance~age|Subject, groups=Series, data=fit.all, layout=c(11,1),
       panel=panel.superpose.2, type=c("p","l","l","l"),
       col=c("black","black","red","blue"), lwd=2,
       main="\nLM (black) and LME (red, blue)")

-logLik(ortho.lm)     # 44.49688 (df=13)
-logLik(ortho.lme)    # 70.60916 (df=4)
-logLik(ortho.lmeML)  # 69.01520 (df=4)

summary(ortho.lm)$sigma                                     # 0.7800331
print(summary(ortho.lme$modelStruct), ortho.lme$sigma)      # 0.7800331  2.06847
print(summary(ortho.lmeML$modelStruct), ortho.lmeML$sigma)  # 0.7681235  1.96987

## Model        -logL     sigma      sigmaB
## ortho.lm     44.49688  0.7800331
## ortho.lme    70.60916  0.7800331  2.06847
## ortho.lmeML  69.01520  0.7681235  1.96987




## ADMB-RE
ortho.matrix <- matrix(ortho$distance, ncol=4, byrow=TRUE)
dimnames(ortho.matrix) <- list(unique(ortho$Subject),unique(ortho$age))

## Model  -logL    sigma     sigmaB
## lm     44.4969  0.665215
## lme    69.0152  0.768123  1.96987
## lmeu   69.0152  0.768123  1.96987




sdp <- function(x) sqrt(sum((x-mean(x))^2) / length(x))  # sigmaMLE = sqrt(RSS/n)
sdp(ortho.lm$res)
sqrt(sum(ortho.lm$res^2)/32)
-logLik(ortho.lm)
