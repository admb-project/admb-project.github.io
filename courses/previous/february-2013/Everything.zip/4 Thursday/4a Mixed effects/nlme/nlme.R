library(nlme)


## 1  Plot data
x <- unique(Orange$age)
y <- xtabs(circumference~Tree+age, data=Orange)
y <- as.matrix(as.data.frame(as.matrix(unclass(y))))
y <- y[as.character(1:5),]
matplot(x, t(y), pch=16, xlim=c(0,1600), ylim=c(0,220), xlab="Age",
        ylab="Circumference")


## 2  Fit NLME
nlme.fm <- nlme(circumference~phi1/(1+exp(-(age-phi2)/phi3)),
                fixed=phi1+phi2+phi3~1, random=phi1~1|Tree,
                data=Orange, start=c(phi1=200,phi2=800,phi3=400))
nlme.fit <- matrix(fitted(nlme.fm), nrow=5, byrow=TRUE)
dimnames(nlme.fit) <- dimnames(y)
matlines(x, t(nlme.fit), lty=1, lwd=2)
title(main="NLME")


## 3  ADMB
## orafix.fit <- suppressWarnings(read.table("c:/nlme/orafix.rep"))
## orafix.fit <- as.matrix(orafix.fit)
## dimnames(orafix.fit) <- dimnames(y)
## oramix.fit <- suppressWarnings(read.table("c:/nlme/oramix.rep"))
## oramix.fit <- as.matrix(oramix.fit)
## dimnames(oramix.fit) <- dimnames(y)
## matplot(x, t(y), pch=16, xlim=c(0,1600), ylim=c(0,220), xlab="Age",
##         ylab="Circumference", main="ADMB (MIXED=solid, FIXED=dashed)")
## matlines(x, t(oramix.fit), lty=1, lwd=2)
## matlines(x, t(orafix.fit), lty=2, lwd=2, col="black")
