################################################################################
###                                                                            #
### Script:    fsa.R                                                           #
###                                                                            #
### Purpose:   Plot and discuss simple statistical catch-at-age model          #
###                                                                            #
### Functions: readVec, readMat, importFSA                                     #
###                                                                            #
### Requires:  package:scape, fsa.dat, fsa.par                                 #
###                                                                            #
### Notes:     fsa.dat and fsa.par are ADMB input/output files                 #
###                                                                            #
### History:   2013-20-02 Arni Magnusson created for ICES ADMB workshop        #
###                                                                            #
################################################################################

readVec <- function(string, file, verbose=FALSE)
### Find 'string' in 'file' and read vector from next line
{
  if(verbose) cat(paste("    Importing", string, "in", file, "..."))
  txt <- readLines(file)
  skip <- match(string, txt)
  vec <- scan(file, quiet=TRUE, skip=skip, nlines=1)
  if(verbose) cat(paste("OK\n"))
  return(vec)
}

readMat <- function(string, file, nrow, verbose=FALSE)
### Find 'string' in 'file' and read matrix with 'nrow' rows from next line
{
  if(verbose) cat(paste("    Importing", string, "in", file, "..."))
  txt <- readLines(file)
  skip <- match(string, txt)
  mat <- as.matrix(read.table(file, skip=skip, nrows=nrow))
  dimnames(mat) <- NULL
  if(verbose) cat(paste("OK\n"))
  return(mat)
}

require(scape)
importFSA <- function(run="c:/fsa/fsa", info="", verbose=FALSE)
### Import model data and fit
{
  if(verbose) cat(paste("\n1 IMPORTING DAT & PAR\n"))
  if(verbose) cat(paste("  (a) model dims\n"))
  ## 1a  Import model dimensions
  datfile <- paste0(run, ".dat")
  minAge <- readVec("# minAge", datfile, verbose=verbose)
  maxAge <- readVec("# maxAge", datfile, verbose=verbose)
  minYear <- readVec("# minYear", datfile, verbose=verbose)
  maxYear <- readVec("# maxYear", datfile, verbose=verbose)
  ages <- minAge:maxAge
  nages <- length(ages)
  years <- minYear:maxYear
  nyears <- length(years)

  if(verbose) cat(paste("  (b) survey dims\n"))
  ## 1b  Import survey dimensions
  minAgeS <- readVec("# minAgeS", datfile, verbose=verbose)
  maxAgeS <- readVec("# maxAgeS", datfile, verbose=verbose)
  minYearS <- readVec("# minYearS", datfile, verbose=verbose)
  maxYearS <- readVec("# maxYearS", datfile, verbose=verbose)
  ages.s <- minAgeS:maxAgeS
  nages.s <- length(ages.s)
  years.s <- minYearS:maxYearS
  nyears.s <- length(years.s)

  if(verbose) cat(paste("  (c) data\n"))
  ## 1c  Import data
  catch <- readMat("# catch in numbers", datfile, nages)
  weight <- readMat("# stock mean weight", datfile, nages)
  maturity <- readMat("# prop mature", datfile, nages)
  natmort <- readMat("# Assumed M", datfile, nages)
  surveyTime <- readVec("# survey time (fraction into year)", datfile, verbose=verbose)
  survey <- readMat("# Q1 survey", datfile, nages.s)

  if(verbose) cat(paste("  (d) parameters\n"))
  ## 1d  Import parameter estimates
  parfile <- paste0(run, ".par")
  logN1Y <- readVec("# logN1Y:", parfile, verbose=verbose)
  logN1A <- readVec("# logN1A:", parfile, verbose=verbose)
  logFY <- readVec("# logFY:", parfile, verbose=verbose)
  logFA <- readVec("# logFA:", parfile, verbose=verbose)
  logVarC <- readVec("# logVarLogCatch:", parfile, verbose=verbose)
  logQ <- readVec("# logQ:", parfile, verbose=verbose)
  logVarS <- readVec("# logVarLogSurvey:", parfile, verbose=verbose)

  if(verbose) cat(paste("\n2 CALCULATING QUANTITIES OF INTEREST\n"))
  if(verbose) cat(paste("  (a) f, m, z\n"))
  ## 2a  Calculate F, M, Z
  Fa <- c(exp(logFA), 1, 1, 1)
  names(Fa) <- ages
  Ft <- exp(logFY)
  names(Ft) <- years
  Fmat <- outer(Ft, Fa)
  M <- t(natmort)
  dimnames(M) <- dimnames(Fmat)
  Z <- Fmat+M

  if(verbose) cat(paste("  (b) fbar, sel\n"))
  ## 2b  Calculate Fbar24, Sel
  Fbar24 <- rowMeans(Fmat[,2:4])
  SelC <- c(exp(logFA), 1, 1, 1)
  SelC <- SelC / max(SelC)
  names(SelC) <- ages
  Q <- exp(logQ)
  SelS <- Q / max(Q)

  if(verbose) cat(paste("  (c) n\n"))
  ## 2c  Calculate N
  N <- matrix(0, nrow=nyears, ncol=nages, dimnames=dimnames(Fmat))
  N[1,] <- exp(logN1Y)
  N[-1,1] <- exp(logN1A)
  for(t in 1:(nyears-1))
  {
    N[t+1,-1] <- N[t,-maxAge] * exp(-Z[t,-maxAge])
  }

  if(verbose) cat(paste("  (d) sb, vb, r\n"))
  ## 2d  Calculcate SB, VB, R
  mat <- t(maturity)
  dimnames(mat) <- dimnames(N)
  w <- t(weight)
  dimnames(w) <- dimnames(N)
  SB <- rowSums(N * w * mat)               # spawning biomass (mature)
  VB <- rowSums(sweep(N*w, 2, SelC, "*"))  # vulnerable biomass (fleet selected)
  R <- c(N[-1,1], NA)                      # recruitment (by birth year)

  if(verbose) cat(paste("  (d) ca, q, sigma\n"))
  ## 2e  Calculate CA, q, sigma
  CAc.obs <- t(catch)
  dimnames(CAc.obs) <- list(years, ages)
  CAc.fit <- Fmat/Z * N*(1-exp(-Z))
  sigmaC <- sqrt(exp(logVarC))
  CAs.obs <- t(survey)
  dimnames(CAs.obs) <- list(years.s, ages.s)
  sigmaS <- sqrt(exp(logVarS))
  Nsurvey <- N[as.character(years.s),ages.s]
  Zsurvey <- Z[as.character(years.s),ages.s]
  CAs.fit <- sweep(Nsurvey * exp(-Zsurvey*surveyTime), 2, Q, "*")

  if(verbose) cat(paste("\n3 CONSTRUCTING MODEL OBJECT\n"))
  ## 3  Construct scape
  if(verbose) cat(paste("  * N\n"))
  N.out <- data.frame(Sex="Unisex", Year=rep(years,each=nages),
                      Age=rep(ages,nyears), N=c(t(N)))
  if(verbose) cat(paste("  * B\n"))
  B.out <- data.frame(Year=years, VB=VB, SB=SB, Y=NA_real_, R=R)
  if(verbose) cat(paste("  * Sel\n"))
  Sel.out <- data.frame(Series=rep(c("Fleet","Survey","Maturity"),
                          c(nages,nages.s,nages)), Sex="Unisex",
                        Age=c(ages,ages.s,ages), P=c(SelC,SelS,colMeans(mat)))
  div <- 1e3
  if(verbose) cat(paste("  * CAc\n"))
  CAc.out <- data.frame(Series="Fleet", Year=rep(years,each=nages), SS=sigmaC,
                        Sex="Unisex", Age=rep(ages,nyears),
                        Obs=c(t(CAc.obs))/div, Fit=c(t(CAc.fit))/div)
  if(verbose) cat(paste("  * CAs\n"))
  CAs.out <- data.frame(Series="Survey", Year=rep(years.s,each=nages.s),
                        SS=sigmaS, Sex="Unisex", Age=rep(ages.s,nyears.s),
                        Obs=c(t(CAs.obs)), Fit=c(t(CAs.fit)))
  model <- list(N=N.out, B=B.out, Sel=Sel.out, CAc=CAc.out, CAs=CAs.out)
  attr(model,"call") <- match.call()
  attr(model,"scape.version") <- installed.packages()["scape","Version"]
  attr(model,"info") <- info
  class(model) <- "scape"

  return(model)
}

## Import and plot

model <- importFSA()

plotSel(model, together=T, strip=F, main="\nSelectivity and maturity")

plotCA(model, fit=F)
plotCA(model, main="\nCommercial CA")
plotCA(model, same=F, main="\nCommercial CA")
plotCA(model, log=T, main="\nCommercial CA")
plotCA(model, log=T, swap=T, main="\nCommercial CA")

plotCA(model, "s", fit=F)
plotCA(model, "s", log=T, main="\nSurvey CA")
plotCA(model, "s", log=T, swap=T, main="\nSurvey CA")

plotN(model, div=1e3)
plotN(model, "b", xlab="Age", cex.points=.6, main="\nPopulation numbers at age")
plotN(x.cod, "b", main="\nIcelandic cod")

plotB(model, div=1e3, main="\nBiomass", ylab="kt")

round(model$N[model$N$Year==2007,]$N/1000, 1)
