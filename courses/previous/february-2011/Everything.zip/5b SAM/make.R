# Small script intended to replace 'make' for running SAM 
# locally on computers without 
#
# Anders Nielsen <anders@nielsensweb.org> Nov. 2010. 

#set path to this file
sam.home<-'~/talks/dfoVisit/newdir/SAM'
setwd(sam.home)

make.clean<-function(){
  setwd(paste(sam.home,'/baserun',sep=''))
  unlink(dir())  
  setwd(paste(sam.home,'/run',sep=''))
  unlink(dir())  
  setwd(paste(sam.home,'/res',sep=''))
  unlink(dir())
  setwd(paste(sam.home,'/runRETRO',sep=''))
  unlink(dir())
  setwd(paste(sam.home,'/runLO',sep=''))
  unlink(dir())
  setwd(sam.home)  
}

make.compile<-function(){
  setwd(paste(sam.home,'/run',sep=''))
  file.copy('../data/ssass.tpl','ssass.tpl',overwrite=TRUE)
  system('admb -r ssass')
  setwd(sam.home)
}

make.data<-function(){
  setwd(paste(sam.home,'/data',sep=''))
  source('datascript.R')
  setwd(sam.home)
}

make.run<-function(){
  setwd(sam.home)
  make.data()
  file.copy('conf/model.cfg','run',overwrite=TRUE)
  file.copy('conf/model.init','run',overwrite=TRUE)
  file.copy('conf/reduced.cfg','run',overwrite=TRUE)
  setwd(paste(sam.home,'/run',sep=''))
  system('./ssass -noinit')
  setwd(sam.home)
}

make.updateBase<-function(){
  setwd(sam.home)
  unlink('baserun', recursive = TRUE)
  dir.create('baserun')
  setwd(paste(sam.home,'/run',sep=''))  
  filelist<-dir()
  for(f in filelist){
    file.copy(f,paste('../baserun/',f,sep=''))
  }
  setwd(sam.home)  
}

make.plot<-function(all=FALSE){
  setwd(sam.home)
  if(all){
    source('conf/plotscriptlong.R')
  }else{
    source('conf/plotscript.R')
  }
  setwd(sam.home)  
}

make.retro<-function(){
  setwd(sam.home)
  source('conf/common.R')
  system('cp -r run/* runRETRO')
  setwd('runRETRO')
  red<-as.numeric(read.table('reduced.cfg')[1,])
  RETRO<-list()
  for(i in 1:10){
    cat(paste('Now running ',i,' out of ', 10, ' retrospective runs.\n', sep=''), file='header.txt')
    red <- rep(i,length(red))
    cat(red,file='reduced.cfg')
    system('./ssass -noinit')
    RETRO[[i]]<-read.fit('ssass')[c('years','fbar','ssb')]
  }
  setwd(paste(sam.home,'/run',sep=''))
  save(RETRO,file='RETRO.RData')
  setwd(sam.home)
}

make.lo<-function(){
  setwd(sam.home)
  source('conf/common.R')
  system('cp -r run/* runLO')
  setwd('runLO')
  red<-as.numeric(read.table('reduced.cfg')[1,]);
  LO<-list();
  for(i in 2:length(red)){
    cat(paste('Now running ',i-1,' out of ',
        length(red)-1, ' leave-one-out runs.\n', sep=''), file='header.txt')
    red<-rep(0,length(red))
    red[i] <- -1
    cat(red,file='reduced.cfg')
    system('./ssass -noinit')
    fit<-read.fit('ssass') 
    fit$civec<-civec(fit)  
    LO[[i-1]]<-fit[c('years','fbar','ssb','civec')]
    file.copy("../run/ssass.par","ssass.par",TRUE);
  }
  setwd(paste(sam.home,'/run',sep=''))
  save(LO,file='LO.RData')
  setwd(sam.home)
}


make.all<-function(){
  make.compile()
  make.run()
  make.updateBase()
  make.plot()
}